#!/bin/bash 

set -x 
echo 1st echo
set +x 
echo 2nd echo
